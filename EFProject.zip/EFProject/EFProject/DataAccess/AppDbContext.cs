﻿using EFProject.Core.Entities;
using Microsoft.EntityFrameworkCore;

namespace EFProject.DataAccess;

public class AppDbContext:DbContext
{
    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseSqlServer(@"Server=TITAN00\SQLEXPRESS;Database=P238EFDb;Trusted_Connection=true;");
    }
    public DbSet<Product> Products { get; set; }
}
