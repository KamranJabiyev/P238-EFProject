﻿namespace EFProject.Core.Entities;

public class Product
{
    //public int ID { get; set; }
    //public int id { get; set; }
    //public int productid { get; set; }
    //public int ProductId { get; set; }
    public int Id { get; set; }
    public string Name { get; set; }
    public decimal Price { get; set; }
}
