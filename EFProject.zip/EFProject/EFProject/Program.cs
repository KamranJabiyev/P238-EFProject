﻿using EFProject.Core.Entities;
using EFProject.DataAccess;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using System;

Console.WriteLine("EF Project:");

AppDbContext context = new AppDbContext();
#region Added

//Product p1 = new()
//{
//    Id = 7,
//    Name = "Apple",
//    Price = 3000
//};
//context.Products.Attach(p1);
//Console.WriteLine(context.Entry(p1).State);
//context.SaveChanges();
//Product p2 = new()
//{
//    Name = "Blackberry",
//    Price = 300
//};
//Product p3 = new()
//{
//    Name = "Nokia",
//    Price = 300
//};
//Console.WriteLine(context.Entry(p1).State);
//context.Entry(p1).State = EntityState.Added;
//await context.AddAsync(p1);
//Console.WriteLine(context.Entry(p1).State);
//await context.SaveChangesAsync();
//await context.Products.AddRangeAsync(p1,p2,p3);
//await context.SaveChangesAsync();
//await context.Products.AddAsync(p2);
//Console.WriteLine(context.Entry(p1).State);
#endregion

#region Update
//Product product =await context.Products.FindAsync(2);
#region Select queries
//Product product = context.Products.FirstOrDefault(p=>p.Id==2);
//Product product = context.Products.Where(p => p.Id == 2).FirstOrDefault();
//Product product = context.Products.First();
#endregion
//Console.WriteLine(context.Entry(product).State);
//product.Price = 1000;
//await context.SaveChangesAsync();

//Product p1 = new()
//{
//    Id = 1,
//    Name = "Motorolla Pro X Max",
//    Price = 1500
//};
//context.Entry(p1).State = EntityState.Modified;
//Console.WriteLine(context.Entry(p1).State);
//context.Update(p1);
//await context.SaveChangesAsync();
#endregion

#region Delete
//Product product = await context.Products.FindAsync(3);
//context.Products.Remove(product);
//Console.WriteLine(context.Entry(product).State);
//await context.SaveChangesAsync();
//Console.WriteLine(context.Entry(product).State);
//Product p1 = new()
//{
//    Id = 1
//};
//context.Entry(p1).State=EntityState.Deleted;
//context.Remove(p1);
//await context.SaveChangesAsync();
#endregion

#region IQuerable & IEnumarable
//decimal price = 150;
//var result = context.Products.Where(p=>p.Price>price);
//price = 250;
//foreach (var item in result)
//{
//    Console.WriteLine(item.Name+" - "+item.Price);
//}
#endregion
